"""Extract pixels with any RGB channel >= 64 into tmp_1; union mask to mask.png."""
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "tmp"
OUT_DIR = ROOT / "tmp_1"
THRESHOLD = 64
MAGENTA = (255, 0, 255)


def main() -> None:
    paths = sorted(SRC.glob("*.png"))
    if not paths:
        raise SystemExit(f"No PNG files in {SRC}")

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    mask_accum: np.ndarray | None = None

    for p in paths:
        im = Image.open(p).convert("RGB")
        arr = np.asarray(im, dtype=np.uint8)
        if mask_accum is None:
            mask_accum = np.zeros(arr.shape[:2], dtype=bool)

        hit = (arr >= THRESHOLD).any(axis=2)
        mask_accum |= hit

        rgba = np.zeros((arr.shape[0], arr.shape[1], 4), dtype=np.uint8)
        rgba[:, :, :3] = arr
        rgba[:, :, 3] = (hit.astype(np.uint8) * 255)
        Image.fromarray(rgba, "RGBA").save(OUT_DIR / p.name, compress_level=6)

    assert mask_accum is not None
    h, w = mask_accum.shape
    mask_rgb = np.zeros((h, w, 3), dtype=np.uint8)
    mask_rgb[mask_accum] = MAGENTA
    Image.fromarray(mask_rgb, "RGB").save(ROOT / "mask.png", compress_level=6)

    print(f"Frames: {len(paths)}")
    print(f"Output: {OUT_DIR}")
    print(f"mask.png: {mask_accum.sum()} / {h * w} pixels marked magenta")


if __name__ == "__main__":
    main()
