"""Build per-circle timelines from orbit_analysis.json: 出现 / 顺时针旋转 / 消失."""
from __future__ import annotations

import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import linear_sum_assignment

ROOT = Path(__file__).resolve().parent
ORBIT_JSON = ROOT / "orbit_analysis.json"
OUT_JSON = ROOT / "orbit_timelines.json"

# Match consecutive frames if center distance <= this (px); chord between adjacent dots ~22
MAX_MATCH_DIST = 12.0
# Count as orbit rotation step if unwrapped delta in (MIN, MAX) deg per frame
DROT_MIN = 1.5
DROT_MAX = 25.0


def load_orbit(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def det_xy(c: dict) -> tuple[float, float]:
    return float(c["x"]), float(c["y"])


def dist(a: tuple[float, float], b: tuple[float, float]) -> float:
    return float(math.hypot(a[0] - b[0], a[1] - b[1]))


def match_pair(
    prev: list[dict], curr: list[dict]
) -> tuple[list[tuple[int, int]], list[int], list[int]]:
    """Return (pairs), unmatched_prev_idx, unmatched_curr_idx."""
    if not prev or not curr:
        return [], list(range(len(prev))), list(range(len(curr)))
    n, m = len(prev), len(curr)
    cost = np.zeros((n, m), dtype=np.float64)
    for i in range(n):
        pi = det_xy(prev[i])
        for j in range(m):
            cost[i, j] = dist(pi, det_xy(curr[j]))
    ri, cj = linear_sum_assignment(cost)
    pairs: list[tuple[int, int]] = []
    for k in range(len(ri)):
        i, j = int(ri[k]), int(cj[k])
        if cost[i, j] <= MAX_MATCH_DIST:
            pairs.append((i, j))
    matched_i = {p[0] for p in pairs}
    matched_j = {p[1] for p in pairs}
    up = [i for i in range(n) if i not in matched_i]
    uc = [j for j in range(m) if j not in matched_j]
    return pairs, up, uc


def unwrap_deg(seq: list[float]) -> list[float]:
    if not seq:
        return []
    u = [seq[0]]
    for i in range(1, len(seq)):
        d = seq[i] - seq[i - 1]
        while d > 180.0:
            d -= 360.0
        while d < -180.0:
            d += 360.0
        u.append(u[-1] + d)
    return u


def is_cw_step(d_unwrapped: float) -> bool:
    """Clockwise on screen: math angle increases -> positive small delta."""
    return DROT_MIN <= d_unwrapped <= DROT_MAX


def classify_phases(frames_idx: list[int], ang_math: list[float]) -> list[dict[str, Any]]:
    """Split track into 出现 / 顺时针旋转 / 消失 by step deltas on unwrapped math angle."""
    if len(frames_idx) == 1:
        return [
            {
                "phase": "出现",
                "start_frame": frames_idx[0],
                "end_frame": frames_idx[0],
                "n_frames": 1,
            },
        ]

    u = unwrap_deg(ang_math)
    deltas = [u[i + 1] - u[i] for i in range(len(u) - 1)]
    cw_flags = [is_cw_step(d) for d in deltas]

    first_rot = next((i for i, ok in enumerate(cw_flags) if ok), None)
    last_rot = None
    for i in range(len(cw_flags) - 1, -1, -1):
        if cw_flags[i]:
            last_rot = i
            break

    phases: list[dict[str, Any]] = []

    if first_rot is None:
        phases.append(
            {
                "phase": "出现",
                "start_frame": frames_idx[0],
                "end_frame": frames_idx[-1],
                "n_frames": len(frames_idx),
                "note": "未检测到稳定顺时针步进（或仅单帧）；可视为出现/检测不稳",
            }
        )
        return phases

    if first_rot > 0:
        phases.append(
            {
                "phase": "出现",
                "start_frame": frames_idx[0],
                "end_frame": frames_idx[first_rot - 1],
                "n_frames": first_rot,
            }
        )

    assert last_rot is not None
    rot_start = frames_idx[first_rot]
    rot_end = frames_idx[last_rot + 1]
    phases.append(
        {
            "phase": "顺时针旋转",
            "start_frame": rot_start,
            "end_frame": rot_end,
            "n_frames": last_rot - first_rot + 2,
            "mean_step_deg_per_frame": round(
                float((u[last_rot + 1] - u[first_rot]) / max(1, last_rot - first_rot + 1)), 4
            ),
            "cw_step_fraction": round(
                float(sum(1 for f in cw_flags[first_rot : last_rot + 1] if f))
                / max(1, last_rot - first_rot + 1),
                4,
            ),
        }
    )

    if last_rot + 2 < len(frames_idx):
        phases.append(
            {
                "phase": "消失",
                "start_frame": frames_idx[last_rot + 2],
                "end_frame": frames_idx[-1],
                "n_frames": len(frames_idx) - (last_rot + 2),
            }
        )

    return phases


def build_tracks(frames_data: list[dict]) -> list[dict[str, Any]]:
    """Hungarian matching between consecutive frames; extend tracks across empty frames."""
    tracks: list[dict[str, Any]] = []
    next_id = 0
    prev_circles: list[dict] = []
    prev_frame_idx: int = -1
    prev_map: dict[int, int] = {}

    def new_track(frame_idx: int, fr: dict, c: dict) -> int:
        nonlocal next_id
        tid = next_id
        next_id += 1
        tracks.append(
            {
                "track_id": tid,
                "points": [
                    {
                        "frame": frame_idx,
                        "file": fr["file"],
                        **{k: c[k] for k in c if k != "id"},
                    }
                ],
            }
        )
        return tid

    for frame_idx, fr in enumerate(frames_data):
        circles = fr["circles"]

        if prev_frame_idx < 0:
            for j, c in enumerate(circles):
                prev_map[j] = new_track(frame_idx, fr, c)
            prev_circles = circles
            prev_frame_idx = frame_idx
            continue

        if not prev_circles and not circles:
            prev_frame_idx = frame_idx
            continue

        if not prev_circles and circles:
            prev_map = {}
            for j, c in enumerate(circles):
                prev_map[j] = new_track(frame_idx, fr, c)
            prev_circles = circles
            prev_frame_idx = frame_idx
            continue

        if prev_circles and not circles:
            for i in list(prev_map.keys()):
                tid = prev_map.pop(i, None)
                if tid is not None:
                    tracks[tid]["end_frame"] = prev_frame_idx
            prev_circles = []
            prev_frame_idx = frame_idx
            continue

        pairs, uprev, unew = match_pair(prev_circles, circles)

        for i in uprev:
            tid = prev_map.pop(i, None)
            if tid is not None:
                tracks[tid]["end_frame"] = prev_frame_idx

        new_map: dict[int, int] = {}
        for i, j in pairs:
            tid = prev_map.pop(i)
            c = circles[j]
            tracks[tid]["points"].append(
                {
                    "frame": frame_idx,
                    "file": fr["file"],
                    **{k: c[k] for k in c if k != "id"},
                }
            )
            new_map[j] = tid
        for j in unew:
            c = circles[j]
            new_map[j] = new_track(frame_idx, fr, c)

        prev_map = new_map
        prev_circles = circles
        prev_frame_idx = frame_idx

    for tr in tracks:
        if "end_frame" not in tr:
            tr["end_frame"] = tr["points"][-1]["frame"]
        tr["start_frame"] = tr["points"][0]["frame"]

    return tracks


def main() -> None:
    data = load_orbit(ORBIT_JSON)
    frames_data = data["frames"]
    tracks_raw = build_tracks(frames_data)

    timelines: list[dict[str, Any]] = []
    for tr in tracks_raw:
        pts = tr["points"]
        if not pts:
            continue
        frames_idx = [int(p["frame"]) for p in pts]
        ang_math = [float(p["angle_math_deg"]) for p in pts]
        phases = classify_phases(frames_idx, ang_math)
        timelines.append(
            {
                "track_id": tr["track_id"],
                "start_frame": tr["start_frame"],
                "end_frame": tr["end_frame"],
                "duration_frames": tr["end_frame"] - tr["start_frame"] + 1,
                "n_observations": len(pts),
                "phase_sequence": [p["phase"] for p in phases],
                "phases": phases,
                "trajectory": pts,
            }
        )

    lens = [t["duration_frames"] for t in timelines]
    seg_counts = Counter()
    frame_totals = Counter()
    for t in timelines:
        for ph in t["phases"]:
            name = ph["phase"]
            seg_counts[name] += 1
            frame_totals[name] += int(ph.get("n_frames", 0))

    summary = {
        "source": str(ORBIT_JSON.name),
        "match_max_dist_px": MAX_MATCH_DIST,
        "rotation_step_deg_range": [DROT_MIN, DROT_MAX],
        "n_tracks": len(timelines),
        "duration_frames_mean": round(float(np.mean(lens)), 4) if lens else 0.0,
        "duration_frames_median": float(np.median(lens)) if lens else 0.0,
        "phase_segment_counts": dict(seg_counts),
        "phase_frame_totals": dict(frame_totals),
        "method_note": (
            "相邻帧用匈牙利算法按圆心距离关联；阶段由 unwrap(angle_math) 的步进是否在 "
            f"[{DROT_MIN},{DROT_MAX}]° 判定顺时针旋转。首/末未出现独立阶段时该段省略。"
        ),
    }

    out = {
        "summary": summary,
        "timelines": timelines,
    }
    OUT_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote", OUT_JSON, "tracks", len(timelines))


if __name__ == "__main__":
    main()
