"""Detect small circles in tmp_2, fit orbit, write orbit_analysis.json."""
from __future__ import annotations

import json
import math
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parent
TMP2 = ROOT / "tmp_2"
OUT_JSON = ROOT / "orbit_analysis.json"


def detect_circles(rgba: np.ndarray) -> list[tuple[float, float, float]]:
    al = rgba[..., 3].astype(np.float32)
    pos = al[al > 0]
    thr = 8.0 if pos.size == 0 else max(5.0, float(np.percentile(pos, 15)))
    mask = (al >= thr).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out: list[tuple[float, float, float]] = []
    for c in cnts:
        area = cv2.contourArea(c)
        if area < 5 or area > 130:
            continue
        (x, y), r = cv2.minEnclosingCircle(c)
        if r < 1.0 or r > 6.0:
            continue
        out.append((float(x), float(y), float(r)))
    return out


def fit_circle(points: np.ndarray) -> tuple[float, float, float]:
    pts = np.asarray(points, dtype=np.float64)

    def residual(p: np.ndarray) -> np.ndarray:
        cx, cy, R = p
        d = np.sqrt((pts[:, 0] - cx) ** 2 + (pts[:, 1] - cy) ** 2)
        return d - R

    cx0, cy0 = pts.mean(axis=0)
    r0 = float(np.median(np.linalg.norm(pts - (cx0, cy0), axis=1)))
    res = least_squares(residual, [cx0, cy0, max(r0, 1.0)], loss="soft_l1", f_scale=0.5)
    return tuple(float(t) for t in res.x)


def main() -> None:
    paths = sorted(TMP2.glob("*.png"))
    if not paths:
        raise SystemExit(f"No PNG in {TMP2}")

    all_pts: list[tuple[float, float]] = []
    all_r: list[float] = []
    per: list[tuple[str, list[tuple[float, float, float]]]] = []
    for p in paths:
        rgba = np.asarray(Image.open(p).convert("RGBA"))
        circ = detect_circles(rgba)
        per.append((p.name, circ))
        for x, y, r in circ:
            all_pts.append((x, y))
            all_r.append(r)

    pts = np.array(all_pts, dtype=np.float64)
    rs = np.array(all_r, dtype=np.float64)
    cx, cy, r_orb = fit_circle(pts)
    lo, hi = np.percentile(rs, [2, 98])
    m = (rs >= lo) & (rs <= hi)

    def ang(x: float, y: float) -> float:
        return float(math.degrees(math.atan2(y - cy, x - cx)))

    def cw_from_east(a: float) -> float:
        return float((-a) % 360.0)

    frames_out: list[dict] = []
    for name, circ in per:
        circ_sorted = sorted(circ, key=lambda t: ang(t[0], t[1]))
        circles = []
        for k, (x, y, r) in enumerate(circ_sorted):
            am = ang(x, y)
            circles.append(
                {
                    "id": k,
                    "x": round(x, 4),
                    "y": round(y, 4),
                    "r_small": round(r, 4),
                    "angle_math_deg": round(am, 4),
                    "angle_cw_from_east_deg": round(cw_from_east(am), 4),
                }
            )
        frames_out.append({"file": name, "n": len(circles), "circles": circles})

    w, h = Image.open(paths[0]).size
    out = {
        "image_size_wh": [w, h],
        "orbit_center_xy": [round(cx, 6), round(cy, 6)],
        "orbit_radius": round(r_orb, 6),
        "small_circle_radius": {
            "mean_trimmed_2_98_pct": round(float(rs[m].mean()), 6),
            "std_trimmed": round(float(rs[m].std()), 6),
            "median_all_detections": round(float(np.median(rs)), 6),
            "n_detections": int(len(rs)),
        },
        "angles": {
            "angle_math_deg": (
                "atan2(y - cy, x - cx)，单位度，约 (-180,180]；"
                "屏幕 y 向下时，角度增大对应从 +x 向 +y 的转向（顺时针）。"
            ),
            "angle_cw_from_east_deg": "从 +x（右）顺时针 0..360°，即 (-angle_math_deg) mod 360。",
        },
        "frames": frames_out,
    }
    OUT_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote", OUT_JSON)


if __name__ == "__main__":
    main()
