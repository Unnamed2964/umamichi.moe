"""Fit cubic Bezier to (frame, unwrapped angle_math_deg) per timeline track."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parent
TIMELINES_JSON = ROOT / "orbit_timelines.json"
OUT_JSON = ROOT / "orbit_angle_bezier.json"


def unwrap_deg(seq: list[float]) -> list[float]:
    """Cumulative angle; steps between samples folded to (-180, 180]. May exceed 360."""
    if not seq:
        return []
    u = [float(seq[0])]
    for i in range(1, len(seq)):
        d = float(seq[i]) - float(seq[i - 1])
        while d > 180.0:
            d -= 360.0
        while d < -180.0:
            d += 360.0
        u.append(u[-1] + d)
    return u


def bezier_eval(
    u: np.ndarray,
    p0: np.ndarray,
    p1: np.ndarray,
    p2: np.ndarray,
    p3: np.ndarray,
) -> np.ndarray:
    """u shape (N,), each row (x,y)."""
    u = np.asarray(u, dtype=np.float64).reshape(-1)
    o = 1.0 - u
    b = (
        (o**3)[:, np.newaxis] * p0
        + 3.0 * (o**2 * u)[:, np.newaxis] * p1
        + 3.0 * (o * u**2)[:, np.newaxis] * p2
        + (u**3)[:, np.newaxis] * p3
    )
    return b


def fit_bezier_xy(
    x: np.ndarray, y: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, float]]:
    """Fix P0=(x0,y0), P3=(x1,y1); optimize P1,P2. x,y are observation coords."""
    x = np.asarray(x, dtype=np.float64).ravel()
    y = np.asarray(y, dtype=np.float64).ravel()
    n = x.size
    if n < 2:
        raise ValueError("need >= 2 points")

    span = float(x[-1] - x[0])
    if span > 1e-9:
        u = (x - x[0]) / span
    else:
        u = np.linspace(0.0, 1.0, n, dtype=np.float64)

    p0 = np.array([x[0], y[0]], dtype=np.float64)
    p3 = np.array([x[-1], y[-1]], dtype=np.float64)
    x0 = np.array(
        [
            p0[0] + (p3[0] - p0[0]) / 3.0,
            p0[1] + (p3[1] - p0[1]) / 3.0,
            p0[0] + 2.0 * (p3[0] - p0[0]) / 3.0,
            p0[1] + 2.0 * (p3[1] - p0[1]) / 3.0,
        ],
        dtype=np.float64,
    )

    pts = np.column_stack([x, y])

    def residual(vec: np.ndarray) -> np.ndarray:
        p1 = np.array([vec[0], vec[1]], dtype=np.float64)
        p2 = np.array([vec[2], vec[3]], dtype=np.float64)
        pred = bezier_eval(u, p0, p1, p2, p3)
        return (pred - pts).ravel()

    xf = float(x.min())
    xt = float(x.max())
    yf = float(y.min())
    yt = float(y.max())
    pad_x = max(5.0, 0.2 * (xt - xf + 1e-6))
    pad_y = max(30.0, 0.2 * (yt - yf + 1e-6))

    bounds_lo = [xf - pad_x, yf - pad_y, xf - pad_x, yf - pad_y]
    bounds_hi = [xt + pad_x, yt + pad_y, xt + pad_x, yt + pad_y]

    res = least_squares(
        residual,
        x0,
        bounds=(bounds_lo, bounds_hi),
        loss="soft_l1",
        f_scale=1.0,
        max_nfev=2000,
    )
    v = res.x
    p1 = np.array([v[0], v[1]], dtype=np.float64)
    p2 = np.array([v[2], v[3]], dtype=np.float64)
    pred = bezier_eval(u, p0, p1, p2, p3)
    err_x = pred[:, 0] - x
    err_y = pred[:, 1] - y
    rmse_xy = float(np.sqrt(np.mean(np.sum((pred - pts) ** 2, axis=1))))
    rmse_y = float(np.sqrt(np.mean(err_y**2)))
    rmse_x = float(np.sqrt(np.mean(err_x**2)))
    max_abs_frame = float(np.max(np.abs(err_x)))
    max_abs_angle_deg = float(np.max(np.abs(err_y)))
    max_abs_euclidean_xy = float(np.max(np.linalg.norm(pred - pts, axis=1)))
    stats = {
        "rmse_angle_deg": round(rmse_y, 6),
        "rmse_frame": round(rmse_x, 6),
        "rmse_euclidean_xy": round(rmse_xy, 6),
        "max_abs_angle_deg": round(max_abs_angle_deg, 6),
        "max_abs_frame": round(max_abs_frame, 6),
        "max_abs_euclidean_xy": round(max_abs_euclidean_xy, 6),
        "cost": float(res.cost),
        "success": bool(res.success),
    }
    return p0, p1, p2, p3, stats


def main() -> None:
    data = json.loads(TIMELINES_JSON.read_text(encoding="utf-8"))
    timelines: list[dict[str, Any]] = data["timelines"]

    fits: list[dict[str, Any]] = []
    for tr in timelines:
        traj = tr.get("trajectory") or []
        if len(traj) < 2:
            continue

        frames = np.array([int(p["frame"]) for p in traj], dtype=np.float64)
        ang_raw = [float(p["angle_math_deg"]) for p in traj]
        theta = np.array(unwrap_deg(ang_raw), dtype=np.float64)

        p0, p1, p2, p3, st = fit_bezier_xy(frames, theta)

        u_sample = np.linspace(0.0, 1.0, 101, dtype=np.float64)
        curve = bezier_eval(u_sample, p0, p1, p2, p3)

        def pt(a: np.ndarray) -> list[float]:
            return [round(float(a[0]), 6), round(float(a[1]), 6)]

        span = float(frames[-1] - frames[0])
        fits.append(
            {
                "track_id": tr["track_id"],
                "start_frame": tr["start_frame"],
                "end_frame": tr["end_frame"],
                "n_points": len(traj),
                "angle_unwrapped_deg_first_last": [
                    round(float(theta[0]), 6),
                    round(float(theta[-1]), 6),
                ],
                "delta_unwrapped_deg": round(float(theta[-1] - theta[0]), 6),
                "parameter_u": "u = (frame - frame_first) / (frame_last - frame_first)；单帧跨度为 0 时 u 全 0。",
                "control_points_frame_angle": {
                    "P0": pt(p0),
                    "P1": pt(p1),
                    "P2": pt(p2),
                    "P3": pt(p3),
                },
                "fit_metrics": st,
                "sample_curve_101": {
                    "u": [round(float(u), 6) for u in u_sample.tolist()],
                    "frame": [round(float(c[0]), 6) for c in curve],
                    "angle_unwrapped_deg": [round(float(c[1]), 6) for c in curve],
                },
            }
        )

    max_ang = max(f["fit_metrics"]["max_abs_angle_deg"] for f in fits) if fits else 0.0
    max_fr = max(f["fit_metrics"]["max_abs_frame"] for f in fits) if fits else 0.0
    max_eu = max(f["fit_metrics"]["max_abs_euclidean_xy"] for f in fits) if fits else 0.0

    out = {
        "source": str(TIMELINES_JSON.name),
        "curve": "三次贝塞尔 B(u)=(1-u)^3 P0 + 3(1-u)^2 u P1 + 3(1-u)u^2 P2 + u^3 P3；P0/P3 固定为首末观测 (frame, unwrap(angle_math_deg))，P1/P2 最小二乘。角度 unwrap 允许连续超过 360°。",
        "n_fits": len(fits),
        "residual_max_over_all_fits": {
            "max_abs_angle_deg": round(float(max_ang), 6),
            "max_abs_frame": round(float(max_fr), 6),
            "max_abs_euclidean_xy": round(float(max_eu), 6),
        },
        "fits": fits,
    }
    OUT_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote", OUT_JSON, "fits", len(fits))


if __name__ == "__main__":
    main()
