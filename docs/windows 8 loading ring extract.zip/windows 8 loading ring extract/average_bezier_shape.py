"""Average normalized phase curve over all Bezier fits in orbit_angle_bezier.json."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parent
IN_JSON = ROOT / "orbit_angle_bezier.json"
OUT_JSON = ROOT / "orbit_bezier_mean_shape.json"


def main() -> None:
    data = json.loads(IN_JSON.read_text(encoding="utf-8"))
    fits: list[dict[str, Any]] = data["fits"]

    rows: list[np.ndarray] = []
    meta: list[dict[str, float | int]] = []
    u_ref: np.ndarray | None = None

    for f in fits:
        sc = f["sample_curve_101"]
        u = np.asarray(sc["u"], dtype=np.float64)
        y = np.asarray(sc["angle_unwrapped_deg"], dtype=np.float64)
        if u_ref is None:
            u_ref = u
        elif u_ref.shape != u.shape or np.max(np.abs(u_ref - u)) > 1e-9:
            raise SystemExit("inconsistent u sampling across fits")

        r = float(y[-1] - y[0])
        if abs(r) < 1e-9:
            continue
        rows.append((y - y[0]) / r)
        meta.append(
            {
                "track_id": int(f["track_id"]),
                "theta0_deg": round(float(y[0]), 6),
                "theta1_deg": round(float(y[-1]), 6),
                "delta_deg": round(float(r), 6),
            }
        )

    if not rows or u_ref is None:
        raise SystemExit("no curves to average")

    y_mat = np.stack(rows)
    mean = y_mat.mean(axis=0)
    std = y_mat.std(axis=0)

    out = {
        "source": str(IN_JSON.name),
        "description": (
            "对每条拟合的 angle(u) 做 (theta(u)-theta0)/(theta1-theta0) 后逐点算术平均。"
            "公共横轴 u 与 sample_curve_101 一致。"
            "单条轨迹近似：theta(u) ≈ theta0 + delta * mean_shape(u)，"
            "其中 delta=theta1-theta0；时间已通过 u 对齐，角度上为「同一平均曲线」的缩放与平移（仿射）。"
        ),
        "n_tracks_averaged": int(y_mat.shape[0]),
        "u": [round(float(x), 6) for x in u_ref.tolist()],
        "mean_normalized_phase": [round(float(x), 6) for x in mean.tolist()],
        "std_normalized_phase": [round(float(x), 6) for x in std.tolist()],
        "per_track_scaling": meta,
    }
    OUT_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    print("wrote", OUT_JSON, "n=", y_mat.shape[0])


if __name__ == "__main__":
    main()
