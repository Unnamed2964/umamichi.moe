"""Fit explicit cubic M(u) to mean shape; write JSON + docs/6.md (time mapping per track)."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parent
MEAN_JSON = ROOT / "orbit_bezier_mean_shape.json"
BEZIER_JSON = ROOT / "orbit_angle_bezier.json"
OUT_JSON = ROOT / "orbit_mean_template_bezier.json"
OUT_MD = ROOT / "docs" / "6.md"


def bezier_M_y(u: np.ndarray, y1: float, y2: float) -> np.ndarray:
    """M(u) with P0=(0,0), P1=(1/3,y1), P2=(2/3,y2), P3=(1,1); x(u)=u exactly."""
    u = np.asarray(u, dtype=np.float64).reshape(-1)
    o = 1.0 - u
    return (
        3.0 * (o**2) * u * y1 + 3.0 * o * (u**2) * y2 + (u**3) * 1.0
    )


def main() -> None:
    mean_data = json.loads(MEAN_JSON.read_text(encoding="utf-8"))
    u = np.asarray(mean_data["u"], dtype=np.float64)
    m = np.asarray(mean_data["mean_normalized_phase"], dtype=np.float64)

    def residual(v: np.ndarray) -> np.ndarray:
        return bezier_M_y(u, float(v[0]), float(v[1])) - m

    res = least_squares(
        residual,
        [0.45, 0.55],
        bounds=([0.0, 0.0], [1.5, 1.5]),
        loss="soft_l1",
        f_scale=0.01,
    )
    y1, y2 = float(res.x[0]), float(res.x[1])
    pred = bezier_M_y(u, y1, y2)
    rmse = float(np.sqrt(np.mean((pred - m) ** 2)))
    max_abs = float(np.max(np.abs(pred - m)))

    bez = json.loads(BEZIER_JSON.read_text(encoding="utf-8"))
    fits = sorted(bez["fits"], key=lambda x: int(x["track_id"]))
    tracks_tbl: list[dict[str, Any]] = []
    for f in fits:
        tid = int(f["track_id"])
        fs = int(f["start_frame"])
        fe = int(f["end_frame"])
        tlen = fe - fs
        u_f = f"u = (f - {fs}) / {tlen}" if tlen > 0 else "u = 0（单帧）"
        th0 = f["angle_unwrapped_deg_first_last"][0]
        dlt = f["delta_unwrapped_deg"]
        tracks_tbl.append(
            {
                "track_id": tid,
                "frame_start": fs,
                "frame_end": fe,
                "duration_frames": tlen,
                "u_from_frame_f": u_f,
                "theta_approx_deg": f"theta(f) ≈ {th0} + ({dlt}) * M(u)",
            }
        )

    out = {
        "source_mean_shape": str(MEAN_JSON.name),
        "template_M_of_u": {
            "domain": "[0,1]",
            "formula": (
                "M(u) = 3(1-u)^2*u*y1 + 3(1-u)*u^2*y2 + u^3，"
                "其中 (y1,y2) 为内控制点纵坐标；x(u)=u（时间参数即 u）。"
            ),
            "control_y1": round(y1, 8),
            "control_y2": round(y2, 8),
            "rmse_vs_mean_shape": round(rmse, 8),
            "max_abs_error": round(max_abs, 8),
            "fit_success": bool(res.success),
        },
        "tracks_time_mapping": tracks_tbl,
    }
    OUT_JSON.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")

    md_lines = [
        "> 以下内容为 GPT-5.2 生成，未经过人工检查，请谨慎对待。本文以 [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) 授权。",
        "",
        "# 平均相位模板曲线与时间轴对应（6）",
        "",
        "承接 [`docs/4.md`](4.md)、[`docs/5.md`](5.md) 与 `orbit_bezier_mean_shape.json`。",
        "",
        "## 1. 模板曲线 \\(M(u)\\)（归一化相位，\\(u\\in[0,1]\\)）",
        "",
        "对 10 条贝塞尔采样做 \\((\\theta(u)-\\theta(0))/(\\theta(1)-\\theta(0))\\) 平均后，用**固定端点**的三次贝塞尔拟合，并约束 **横坐标 \\(x(u)=u\\)**（内控制点取 \\(P_1=(1/3,y_1),\\,P_2=(2/3,y_2)\\)），从而 \\(M(u)\\) 写成**标量**伯恩斯坦形式：",
        "",
        "\\[",
        f"M(u) = 3(1-u)^2 u \\cdot y_1 + 3(1-u)u^2 \\cdot y_2 + u^3,\\quad y_1={y1:.8f},\\; y_2={y2:.8f}.",
        "\\]",
        "",
        "端点 \\(M(0)=0,\\; M(1)=1\\)。与 101 点平均形状的拟合 **RMSE** \\(\\approx {rmse:.6f}\\)，**最大绝对误差** \\(\\approx {max_abs:.6f}\\)。",
        "",
        "数值与逐轨时间映射见 **`orbit_mean_template_bezier.json`**。复现：",
        "",
        "```bash",
        "python average_bezier_shape.py",
        "python export_mean_template_curve.py",
        "```",
        "",
        "## 2. 各圆在**时间轴**上与模板的关系",
        "",
        "模板 \\(M\\) 定义在**无量纲时间** \\(u\\in[0,1]\\)。第 \\(i\\) 条轨迹在**全局帧** \\(f\\) 上：",
        "",
        "\\[",
        "u_i(f) = \\frac{f - f_i^{\\mathrm{start}}}{f_i^{\\mathrm{end}} - f_i^{\\mathrm{start}}},\\quad",
        "\\theta_i(f) \\approx \\theta_i^{\\mathrm{start}} + \\bigl(\\theta_i^{\\mathrm{end}}-\\theta_i^{\\mathrm{start}}\\bigr)\\, M\\bigl(u_i(f)\\bigr).",
        "\\]",
        "",
        "因此相对「同一 \\(M\\)」而言，各圆差异是：",
        "",
        "- **时间轴上的位置（平移）**：观测窗口 \\([f_i^{\\mathrm{start}},\\,f_i^{\\mathrm{end}}]\\) 在全局帧上的**起点** \\(f_i^{\\mathrm{start}}\\) 即「模板 \\(u=0\\) 对齐到该帧」；**终点**对齐 \\(u=1\\)。",
        "- **时间轴上的缩放**：窗口长度 \\(T_i = f_i^{\\mathrm{end}}-f_i^{\\mathrm{start}}\\) 把 \\(u\\in[0,1]\\) **线性拉伸**到 \\(T_i\\) 帧（不是刚性平移整条动画，而是**平移 + 均匀拉伸**到各自时长）。",
        "- **角度上的仿射**：\\(\\theta_i^{\\mathrm{start}}\\) 与总转角 \\(\\Delta_i=\\theta_i^{\\mathrm{end}}-\\theta_i^{\\mathrm{start}}\\) 对应竖直方向的平移与缩放。",
        "",
        "### 逐轨表（摘自当前 `orbit_angle_bezier.json`）",
        "",
        "| track_id | \\(f^{\\mathrm{start}}\\) | \\(f^{\\mathrm{end}}\\) | 时长 \\(T\\) | \\(u(f)\\) | \\(\\theta(f)\\) 近似 |",
        "|:---:|:---:|:---:|:---:|:---|:---|",
    ]
    for row in tracks_tbl:
        md_lines.append(
            f"| {row['track_id']} | {row['frame_start']} | {row['frame_end']} | "
            f"{row['duration_frames']} | `{row['u_from_frame_f']}` | `{row['theta_approx_deg']}` |"
        )
    md_lines.extend(
        [
            "",
            "---",
            "",
            "**小结**：「平均曲线」即上式 \\(M(u)\\)；每个圆最自然说成：**同一条 \\(M\\)**，在时间上经 **仿射变换** \\(u=(f-f_0)/T\\) 接到各自可见帧区间，并在角度上乘 \\(\\Delta_i\\)、加 \\(\\theta_i^{\\mathrm{start}}\\)。",
        ]
    )
    OUT_MD.parent.mkdir(parents=True, exist_ok=True)
    OUT_MD.write_text("\n".join(md_lines), encoding="utf-8")
    print("wrote", OUT_JSON)
    print("wrote", OUT_MD)
    print("y1,y2", y1, y2, "rmse", rmse)


if __name__ == "__main__":
    main()
